import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    String str1="welcome";
	    String str2="hello";
	  String str3=(str1+str2);
		System.out.println(str3);
	}
}
